import SingleTemplate from "./single";

 
const templates = {
	single: SingleTemplate,
};
 
export default 
templates;
