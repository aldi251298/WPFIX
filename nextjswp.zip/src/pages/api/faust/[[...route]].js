import "@config";
 
export { apiRouter as default } from "@faustwp/core";